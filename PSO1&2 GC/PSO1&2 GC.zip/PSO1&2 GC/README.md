# Phantasy Star Online Episodes 1 & 2 
### NTSC-U Gamecube Gecko Codes
___
##### Conditional Codes:
+ Max Money in Bank ~ D - Pad Down + Right
+ Revive in Single Player ~ L*
+ Jump to Level 100 ~ L + R + Z + D - pad Up
(will not bring your level down, only up)
##### Constant Codes:
 + Infinite Health*
 + Infinite TP
 + Bank Mod
 + Enemys will drop Rare Loot

 \**Because of the nature of these two cheats I have supplied two different cheat (\*.gci) files with either one.*
### Download
Type            | Link
----------------|------------
Infinite Health | link 1
Revive with L   | link 2

### Bank Mod
The bank mod is a complex code that takes the value of your balance in the bank and transmutes the first item in the bank to match that value

 *i.e.) bank balance = 13312 == 0x3400 : first item in bank will be a Red Sword*

Item Name   | Decimal Value | Hex Value
------------|---------------| ----------
Red Sword | 13312 | 0x3400
Revive with L   | link 2 | link 3

### Disclaimer
**These codes are a work in progress so I am welcome to any reccomendations for additions.**